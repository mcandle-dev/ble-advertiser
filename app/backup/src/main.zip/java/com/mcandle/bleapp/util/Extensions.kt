package com.mcandle.bleapp.utils

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

/**
 * 메인 스레드에서 안전하게 토스트 표시
 */
fun Context.showToast(message: CharSequence) {
    if (Looper.myLooper() == Looper.getMainLooper()) {
        Toast.makeText(this.applicationContext, message, Toast.LENGTH_SHORT).show()
    } else {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this.applicationContext, message, Toast.LENGTH_SHORT).show()
        }
    }
}

/**
 * 선택: 키보드 내리기 (필요할 때 사용)
 */
fun View.hideKeyboard() {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    imm?.hideSoftInputFromWindow(windowToken, 0)
}
