package com.mcandle.bleapp

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.mcandle.bleapp.advertise.AdvertiserManager
import com.mcandle.bleapp.databinding.ActivityMainBinding
import com.mcandle.bleapp.scan.BleScannerManager
import com.mcandle.bleapp.scan.IBeaconParser
import com.mcandle.bleapp.ui.InputFormFragment
import com.mcandle.bleapp.viewmodel.BleAdvertiseViewModel
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity(), BleScannerManager.Listener {

    // ViewBinding / ViewModel
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: BleAdvertiseViewModel

    // Advertise & Scan managers
    private lateinit var advertiserManager: AdvertiserManager
    private lateinit var scanner: BleScannerManager

    // 버튼으로 요청된 스캔 재개용 보관값
    private var pendingPhone4: String? = null

    // 권한 런처: "버튼 클릭으로 스캔을 요청한 경우"에만 시작되도록 보장
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val denied = results.entries.any { !it.value }
        if (denied) {
            // 권한 거부 → 스캔 상태 되돌리기
            viewModel.onScanError("필수 권한이 거부되었습니다.")
            pendingPhone4 = null
            return@registerForActivityResult
        }
        // 권한 허용됨 → 버튼 클릭으로 보관한 값이 있을 때만 스캔 시작
        pendingPhone4?.let { phone4 ->
            startScan(phone4)
        }
        pendingPhone4 = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ViewModel
        viewModel = ViewModelProvider(this)[BleAdvertiseViewModel::class.java]

        // 기존 광고 매니저 초기화(광고 로직 유지)
        advertiserManager = AdvertiserManager(this, viewModel)

        // 스캐너 초기화 (요구사항: minor=3454 필터; 필요없으면 null)
        scanner = BleScannerManager(
            context = this,
            listener = this,
            expectedMinor = 3454,
            scanTimeoutMs = 15_000L
        )

        // 입력 프래그먼트 표시(전화 4자리 + 시작 버튼)
        supportFragmentManager.beginTransaction()
            .replace(R.id.inputFormFragmentContainer, InputFormFragment())
            .commit()

        // ───────── 광고 버튼/상태 (기존 동작 유지) ─────────
        viewModel.isAdvertising.observe(this) { isAdvertising ->
            binding.btnStart.isEnabled = !isAdvertising
            binding.btnStop.isEnabled = isAdvertising
            binding.btnStart.text = if (isAdvertising) "적용중..." else "Advertise Start"
        }

        binding.btnStart.setOnClickListener {
            if (!advertiserManager.isSupported()) {
                showToast("BLE Advertise를 지원하지 않는 기기입니다.")
                return@setOnClickListener
            }
            val data = viewModel.currentData.value
            if (data == null) {
                showToast("패킷 데이터를 먼저 입력해주세요.")
                return@setOnClickListener
            }
            advertiserManager.startAdvertise(data)
        }

        binding.btnStop.setOnClickListener {
            advertiserManager.stopAdvertise()
        }
        // ────────────────────────────────────────────────

        // "프래그먼트의 시작 버튼" → ViewModel 이벤트 → 여기서만 권한/스캔
        observeStartScanRequest()

        // (선택) 초기 권한 점검: 광고/스캔 둘 다 쓰므로 한 번 체크해두면 UX가 부드럽습니다.
        // 필요 없다면 삭제해도 됩니다.
        precheckPermissions()
    }

    // ViewModel의 원샷 이벤트 수집: 버튼이 눌리면 여기로만 들어오도록!
    private fun observeStartScanRequest() {
        lifecycleScope.launch {
            viewModel.startScanRequest.collect { phone4 ->
                // 버튼 기반 요청만 처리
                pendingPhone4 = phone4
                ensureScanPermissions()
            }
        }
    }

    // 스캔 권한 체크/요청 (API 31+는 BLUETOOTH_SCAN, 이하에선 ACCESS_FINE_LOCATION)
    private fun ensureScanPermissions() {
        val need = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }

        if (need.isNotEmpty()) {
            permissionLauncher.launch(need.toTypedArray())
        } else {
            // 권한 이미 있음 → 버튼으로 보관한 값이 있는 경우에만 시작
            pendingPhone4?.let { phone4 ->
                startScan(phone4)
                pendingPhone4 = null
            }
        }
    }

    // (선택) 초기에 광고/스캔 관련 권한을 한 번에 확인하고 싶다면 사용
    private fun precheckPermissions() {
        val all = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            // 광고 + 스캔
            all += listOf(
                Manifest.permission.BLUETOOTH_ADVERTISE,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN
            )
        } else {
            all += Manifest.permission.ACCESS_FINE_LOCATION
        }
        val need = all.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) {
            permissionLauncher.launch(need.toTypedArray())
        }
    }

    // 실제 스캔 시작: 버튼→권한 OK 이후에만 호출
    private fun startScan(phoneLast4: String) {
        if (viewModel.isScanning.value == true || scanner.isScanning) {
            showToast("이미 스캔 중입니다.")
            return
        }
        scanner.startScan(phoneLast4)
        viewModel.setScanning(true)
    }

    private fun stopScan() {
        if (!scanner.isScanning) return
        scanner.stopScan()
        viewModel.setScanning(false)
    }

    // ───────── BleScannerManager.Listener 구현 ─────────

    // 매칭 성공: 다이얼로그 표시(스캐너는 내부에서 이미 stop됨)
    override fun onMatch(frame: IBeaconParser.IBeaconFrame) {
        viewModel.setScanning(false)
        showOrderDialog(frame)
    }

    // 사용자 피드백(토스트 등)
    override fun onInfo(message: String) {
        showToast(message)
    }

    // ───────── 다이얼로그 표시 ─────────

    private fun showOrderDialog(frame: IBeaconParser.IBeaconFrame) {
        val view = LayoutInflater.from(this).inflate(R.layout.order_detail_dialog, null, false)

        // XML의 id가 프로젝트마다 다를 수 있어 안전하게 바인딩합니다.
        runCatching { view.findViewById<TextView>(R.id.tvTitle).text = "주문 확인" }
        runCatching { view.findViewById<TextView>(R.id.tvOrderNo).text = "주문번호: ${frame.orderNumber}" }
        runCatching { view.findViewById<TextView>(R.id.tvPhoneLast4).text = "전화 4자리: ${frame.phoneLast4}" }
        runCatching { view.findViewById<TextView>(R.id.tvMajor).text = "Major: ${frame.major}" }
        runCatching { view.findViewById<TextView>(R.id.tvMinor).text = "Minor: ${frame.minor}" }

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .setCancelable(false)
            .create()

        // 닫기/확인 버튼 id에 맞춰 연결 (없으면 건너뜀)
        runCatching {
            view.findViewById<Button>(R.id.btnClose).setOnClickListener { dialog.dismiss() }
        }
        runCatching {
            view.findViewById<Button>(R.id.btnConfirm).setOnClickListener { dialog.dismiss() }
        }
        dialog.show()
    }

    // ───────── 생명주기 정리 ─────────

    override fun onStop() {
        super.onStop()
        if (scanner.isScanning) stopScan()
    }

    override fun onDestroy() {
        super.onDestroy()
        // 광고/스캔 모두 종료
        advertiserManager.stopAdvertise()
        if (scanner.isScanning) stopScan()
    }

    // ───────── 유틸 ─────────

    private val mainHandler = Handler(Looper.getMainLooper())
    private fun showToast(msg: CharSequence) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
        } else {
            mainHandler.post {
                Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
